# Chaturvedi — Setup Guide

## What changed

Before: every AI provider key sat inside the HTML file, visible to
anyone who opened dev tools. Double-clicking the file worked because
the browser talked directly to Groq, OpenRouter, NVIDIA, and Google.

Now: the browser talks only to your own two functions, `/api/chat`
and `/api/search`. The real keys live on Vercel's servers as
environment variables and never touch the browser.

**This means double-clicking `index.html` no longer gives you a
working assistant.** `/api/chat` isn't a file on your computer — it
only exists once this is deployed to Vercel. Opening the file locally
will show the interface, but every message will fail with "I'm
having trouble reaching my reasoning engine." That's expected. Deploy
it, then always use the live Vercel URL.

## Files in this project

```
index.html       — the interface (markup + styles)
app.js           — all frontend behavior (no keys)
api/chat.js      — backend: talks to Groq/OpenRouter/NVIDIA/Google
api/search.js    — backend: talks to Tavily
SETUP.md         — this file
```

Vercel automatically turns anything inside `/api` into a live
endpoint. No configuration file needed, no build step, no
`package.json` — this works exactly as-is.

## Step 1 — Upload to GitHub

You already have the `chaturvedi-os` repository. Add these four
files, keeping `api/chat.js` and `api/search.js` inside an `api`
folder:

1. Open your repo on GitHub.
2. Click **Add file → Create new file**.
3. In the filename box, type exactly `api/chat.js` — typing the
   slash creates the folder automatically.
4. Paste the contents of `api/chat.js`, then **Commit changes**.
5. Repeat for `api/search.js`.
6. Do the same for `index.html` and `app.js` at the root of the
   repo (no folder prefix), replacing the old versions.

## Step 2 — Set environment variables in Vercel

This is the step that actually protects your keys.

1. Go to your project on **vercel.com**.
2. Click **Settings → Environment Variables**.
3. Add each of these one at a time — paste the **value**, Vercel
   asks for the name separately:

   | Name | Value |
   |---|---|
   | `GROQ_KEY` | your Groq key |
   | `OPENROUTER_KEY` | your OpenRouter key |
   | `NVIDIA_KEY` | your NVIDIA key |
   | `GOOGLE_KEY` | your Google key (optional) |
   | `TAVILY_KEY` | your Tavily key |
   | `APP_SECRET` | `chaturvedi-secret-2026` |

   `APP_SECRET` just needs to match the value already written into
   `app.js`. You can change it to anything — just update both places
   together if you do.

4. Click **Save** after each one.

## Step 3 — Redeploy

Environment variables only apply to new deployments.

1. Go to your project's **Deployments** tab.
2. Click the **⋯** menu on the most recent deployment.
3. Click **Redeploy**.

That's it. Your keys are now server-side only.

## What's honestly true about this setup

- **Real fix**: the four AI provider keys and the Tavily key are no
  longer visible to anyone opening your site. That was the actual
  security hole, and it's closed.
- **`APP_SECRET` is a soft deterrent, not real security.** It's
  embedded in `app.js`, which means it's technically visible in your
  shipped code — same as before. What it *does* do is stop a random
  bot or scraper from finding `/api/chat` on its own and burning
  through your provider quotas without ever loading your actual site.
  It's a speed bump, not a lock. Real protection would mean adding a
  login system, which is a much bigger undertaking and isn't
  necessary for a personal, single-user tool like this.
- **Supabase's key staying in `app.js` is correct, not an oversight.**
  That key is designed to be public — Supabase's own security model
  protects your data through row-level policies on the database
  side, not through keeping the key secret. Different kind of key,
  different rules.
- **The old `CHATURVEDI_OS.bat` launcher still opens the file**, but
  since the AI calls now require a live backend, it'll only show you
  the empty interface. Once deployed, just bookmark your Vercel URL
  and use that instead.
