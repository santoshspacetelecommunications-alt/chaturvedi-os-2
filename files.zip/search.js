/* ══════════════════════════════════════════════════════════
   /api/search — Vercel serverless function (Node.js runtime)

   Holds the Tavily key server-side. The frontend sends a
   plain-text query, this returns a compact block of current
   web context — never the raw key, never the raw API.

   Required environment variable:
     TAVILY_KEY
     APP_SECRET   (must match app.js's APP_SECRET value)
   ══════════════════════════════════════════════════════════ */

module.exports = async function handler(req, res) {
  if (req.method !== 'POST') {
    res.status(405).json({ error: 'method_not_allowed' });
    return;
  }

  const providedSecret = req.headers['x-chaturvedi-key'];
  if (process.env.APP_SECRET && providedSecret !== process.env.APP_SECRET) {
    res.status(401).json({ error: 'unauthorized' });
    return;
  }

  const body = req.body || {};
  const query = body.query;
  if (!query || typeof query !== 'string') {
    res.status(400).json({ error: 'bad_request', detail: 'query string required' });
    return;
  }

  if (!process.env.TAVILY_KEY) {
    res.status(200).json({ context: '' });
    return;
  }

  try {
    const r = await fetch('https://api.tavily.com/search', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        api_key: process.env.TAVILY_KEY,
        query: query,
        max_results: 4,
        include_answer: true
      })
    });

    if (!r.ok) {
      res.status(200).json({ context: '' });
      return;
    }

    const data = await r.json();
    if (!data.results || !data.results.length) {
      res.status(200).json({ context: '' });
      return;
    }

    const lines = data.results.slice(0, 4).map(function (x) {
      return '- ' + x.title + ' \u2014 ' + x.url + '\n  ' + (x.content || '').slice(0, 180);
    }).join('\n');

    const context = '\n\nCurrent information from the web (more recent than your training, use it):\n' + lines;
    res.status(200).json({ context: context });
  } catch (e) {
    res.status(200).json({ context: '' });
  }
};
